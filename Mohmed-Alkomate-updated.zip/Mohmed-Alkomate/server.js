const express = require("express");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const OWNER_CODE = process.env.OWNER_CODE || "";
const SESSION_SECRET = process.env.SESSION_SECRET || "";
const LOCK_MS = 3 * 24 * 60 * 60 * 1000;
const SESSION_MS = 8 * 60 * 60 * 1000;
const STATE_DIR = path.join(__dirname, "data");
const STATE_FILE = path.join(STATE_DIR, "security-state.json");

app.disable("x-powered-by");
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

if (!OWNER_CODE || !SESSION_SECRET) {
  console.warn("تنبيه: عيّن OWNER_CODE و SESSION_SECRET في متغيرات البيئة قبل النشر.");
}

function readState() {
  try { return JSON.parse(fs.readFileSync(STATE_FILE, "utf8")); }
  catch { return {}; }
}
function writeState(state) {
  fs.mkdirSync(STATE_DIR, { recursive: true });
  const tmp = STATE_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(state, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, STATE_FILE);
}
function ipKey(req) {
  // لا تثق في X-Forwarded-For إلا إذا ضبطت trust proxy على استضافتك.
  return crypto.createHash("sha256").update(req.ip || req.socket.remoteAddress || "unknown").digest("hex");
}
function safeEqual(a, b) {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function sign(payload) {
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const mac = crypto.createHmac("sha256", SESSION_SECRET).update(body).digest("base64url");
  return body + "." + mac;
}
function verify(token) {
  if (!SESSION_SECRET || !token || !token.includes(".")) return null;
  const [body, mac] = token.split(".");
  const expected = crypto.createHmac("sha256", SESSION_SECRET).update(body).digest("base64url");
  if (!safeEqual(mac, expected)) return null;
  try {
    const data = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
    return data.exp > Date.now() ? data : null;
  } catch { return null; }
}
function requireOwner(req, res, next) {
  const token = req.cookies?.sayd_owner || req.headers["x-owner-session"];
  const session = verify(token);
  if (!session || session.role !== "owner") return res.status(401).json({ error: "يلزم تسجيل دخول المالك." });
  next();
}

// Minimal cookie parser; avoids an extra dependency.
app.use((req, res, next) => {
  req.cookies = {};
  const raw = req.headers.cookie || "";
  raw.split(";").forEach(part => {
    const i = part.indexOf("=");
    if (i > -1) req.cookies[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  });
  next();
});

app.post("/api/owner/login", (req, res) => {
  if (!OWNER_CODE || !SESSION_SECRET) return res.status(503).json({ error: "إعدادات المالك غير مكتملة على الخادم." });
  const key = ipKey(req);
  const state = readState();
  const item = state[key] || { failures: 0, lockedUntil: 0 };
  const now = Date.now();

  if (item.lockedUntil > now) {
    const hours = Math.ceil((item.lockedUntil - now) / 3600000);
    return res.status(429).json({ error: `تم إيقاف المحاولات مؤقتاً. جرّب بعد حوالي ${hours} ساعة.` });
  }
  if (!safeEqual(req.body?.code || "", OWNER_CODE)) {
    item.failures = (item.failures || 0) + 1;
    if (item.failures >= 3) {
      item.lockedUntil = now + LOCK_MS;
      item.failures = 0;
    }
    state[key] = item;
    writeState(state);
    const remaining = item.lockedUntil > now ? 0 : 3 - item.failures;
    return res.status(401).json({
      error: item.lockedUntil > now
        ? "انتهت المحاولات الثلاث. تم إيقاف الدخول لمدة 3 أيام."
        : `رمز غير صحيح. المحاولات المتبقية: ${remaining}.`
    });
  }

  delete state[key];
  writeState(state);
  const token = sign({ role: "owner", exp: now + SESSION_MS });
  const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
  res.setHeader("Set-Cookie", `sayd_owner=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${Math.floor(SESSION_MS/1000)}${secure}`);
  res.json({ ok: true, message: "تم الدخول إلى لوحة المالك." });
});

app.post("/api/owner/logout", (req, res) => {
  res.setHeader("Set-Cookie", "sayd_owner=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0");
  res.json({ ok: true });
});

app.get("/api/owner/panel", requireOwner, (req, res) => {
  res.json({
    ok: true,
    title: "لوحة المالك",
    features: ["عرض عدد الهواتف المحمّلة", "تحديث قائمة الهواتف", "فحص حالة الخادم", "تسجيل خروج آمن"],
    security: "3 محاولات ثم حظر 72 ساعة",
    note: "لوحة المالك الأساسية مفعّلة. تعديل محتوى قاعدة البيانات وإدارة الصور الجماعية يحتاجان قاعدة بيانات دائمة قبل النشر."
  });
});

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "Mohmed Alkomate" }));

app.listen(PORT, () => console.log(`Mohmed Alkomate running on port ${PORT}`));
