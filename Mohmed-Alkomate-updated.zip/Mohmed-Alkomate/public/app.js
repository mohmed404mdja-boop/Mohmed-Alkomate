const API_BASE = "https://techapi.dev/v1";
const FALLBACK_BASE = "https://gettechapi.github.io/TechAPI/v1";
const $ = (id) => document.getElementById(id);
let phones = [];
let selectedPhones = [];

function getName(p) { return p.name || p.model || p.title || p.slug || "هاتف غير معروف"; }
function getBrand(p) { return p.brand || p.manufacturer || p.brand_name || "غير محدد"; }
function getYear(p) {
  const d = p.release_date || p.announced || p.year || "";
  return String(d).slice(0,4) || "غير محدد";
}
function getSlug(p) { return p.slug || p.id || p.device_slug || ""; }
function getSpecs(p) {
  const display = p.display?.size || p.display_size || p.screen_size || "";
  const ram = p.memory?.ram || p.ram || p.ram_capacity || "";
  const chipset = p.platform?.chipset || p.chipset || p.soc || p.processor || "";
  const battery = p.battery?.capacity || p.battery_capacity || "";
  const storage = p.memory?.internal || p.storage || p.internal_storage || "";
  return {display, ram, chipset, battery, storage};
}
function getImage(p) {
  const candidate = p.image_url || p.image || p.thumbnail || p.images?.front || p.images?.[0]?.url || "";
  return typeof candidate === "string" && /^https:\/\//i.test(candidate) ? candidate : "";
}
function numericRam(v) {
  const m = String(v || "").match(/[0-9]+(?:\.[0-9]+)?/);
  return m ? Number(m[0]) : 8;
}
function numericBattery(v) {
  const m = String(v || "").match(/[0-9]{3,5}/);
  return m ? Number(m[0]) : 5000;
}
function value(v) {
  if (v === undefined || v === null || v === "") return "غير متوفر";
  if (typeof v === "object") return v.value || v.name || JSON.stringify(v);
  return String(v);
}
function normalizeList(data) {
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.data)) return data.data;
  if (Array.isArray(data?.items)) return data.items;
  if (Array.isArray(data?.smartphones)) return data.smartphones;
  return [];
}
async function fetchJson(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error("HTTP " + r.status);
  return r.json();
}
async function loadPhones() {
  $("apiStatus").textContent = "جاري تحميل قائمة الأجهزة من TechAPI...";
  $("phoneGrid").innerHTML = '<article class="device-card skeleton"></article><article class="device-card skeleton"></article><article class="device-card skeleton"></article>';
  let lastError;
  for (const base of [API_BASE, FALLBACK_BASE]) {
    try {
      const data = await fetchJson(`${base}/smartphones/index.json`);
      phones = normalizeList(data);
      if (!phones.length) throw new Error("لم أجد سجلات في صيغة القائمة المتوقعة");
      $("apiStatus").textContent = `تم الاتصال بنجاح. عدد السجلات المستلمة: ${phones.length.toLocaleString("en-US")}.`;
      renderPhones();
      populateCompare();
      fillSimulatorPhones();
      updateSimulation();
      return;
    } catch (e) { lastError = e; }
  }
  $("apiStatus").textContent = "تعذر تحميل القائمة حالياً. يمكنك إعادة المحاولة، وقد يكون تنسيق أو عنوان API قد تغيّر.";
  $("phoneGrid").innerHTML = `<div class="device-card">لم نتمكن من جلب الأجهزة الآن.<br><small>${String(lastError || "").replace(/[<>]/g,"")}</small></div>`;
}
function renderPhones() {
  const q = $("search").value.trim().toLowerCase();
  const brand = $("brandFilter").value.toLowerCase();
  const filtered = phones.filter(p => {
    const hay = `${getName(p)} ${getBrand(p)} ${getYear(p)}`.toLowerCase();
    return hay.includes(q) && (!brand || getBrand(p).toLowerCase().includes(brand));
  }).slice(0, 60);
  $("phoneGrid").innerHTML = filtered.length ? filtered.map((p, i) => {
    const s = getSpecs(p);
    const img = getImage(p);
    return `<article class="device-card" data-index="${phones.indexOf(p)}">
      ${img ? `<img class="device-photo" src="${escapeHtml(img)}" alt="${escapeHtml(getName(p))}" loading="lazy" referrerpolicy="no-referrer" onerror="this.style.display='none'">` : `<div class="device-photo-placeholder">${escapeHtml(getBrand(p))}<span>ANDROID</span></div>`}
      <div class="device-top"><span class="device-brand">${escapeHtml(getBrand(p))}</span><span class="device-year">${escapeHtml(getYear(p))}</span></div>
      <h3>${escapeHtml(getName(p))}</h3>
      <div class="device-specs"><span>${escapeHtml(value(s.display))}${s.display ? " شاشة" : ""}</span><span>${escapeHtml(value(s.ram))}${s.ram ? " RAM" : ""}</span><span>${escapeHtml(value(s.chipset))}</span></div>
      <div class="device-open"><span>عرض التفاصيل</span><span>←</span></div></article>`;
  }).join("") : '<div class="device-card">لا توجد نتائج مطابقة.</div>';
  document.querySelectorAll(".device-card[data-index]").forEach(card => card.addEventListener("click", () => showDetails(phones[Number(card.dataset.index)])));
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
async function showDetails(p) {
  const slug = getSlug(p);
  let d = p;
  if (slug) {
    for (const base of [API_BASE, FALLBACK_BASE]) {
      try { d = await fetchJson(`${base}/smartphones/${encodeURIComponent(slug)}.json`); break; } catch {}
    }
  }
  const s = getSpecs(d);
  const entries = [
    ["الشركة", getBrand(d)], ["سنة الإصدار", getYear(d)],
    ["الشاشة", value(s.display)], ["الذاكرة العشوائية", value(s.ram)],
    ["المعالج", value(s.chipset)], ["البطارية", value(s.battery)],
    ["النظام", value(d.os || d.platform?.os)], ["التخزين", value(s.storage)]
  ];
  const photo = getImage(d);
  $("detailContent").innerHTML = `${photo ? `<img class="detail-photo" src="${escapeHtml(photo)}" alt="${escapeHtml(getName(d))}" onerror="this.style.display='none'">` : ""}<div class="detail-hero"><div class="eyebrow">DEVICE DETAILS</div><h2>${escapeHtml(getName(d))}</h2><p>${escapeHtml(getBrand(d))} · ${escapeHtml(getYear(d))}</p></div><div class="spec-table">${entries.map(([k,v])=>`<div class="spec-item"><small>${escapeHtml(k)}</small><b>${escapeHtml(v)}</b></div>`).join("")}</div><p>المواصفات بحسب سجل TechAPI وقد تختلف باختلاف النسخة والمنطقة. <a href="https://github.com/GetTechAPI/TechAPI" target="_blank" rel="noopener" style="color:#b5f36b">مصدر البيانات</a>.</p>`;
  $("detailModal").classList.remove("hidden");
}
function populateCompare() {
  const opts = phones.slice(0, 1000).map((p,i)=>`<option value="${i}">${escapeHtml(getBrand(p)+" "+getName(p))}</option>`).join("");
  $("compareA").innerHTML = '<option value="">الهاتف الأول</option>' + opts;
  $("compareB").innerHTML = '<option value="">الهاتف الثاني</option>' + opts;
}
function compare() {
  const a = phones[Number($("compareA").value)], b = phones[Number($("compareB").value)];
  if (!a || !b) { $("compareResult").textContent = "اختر هاتفين من القائمة لعرض المقارنة."; return; }
  const sa=getSpecs(a), sb=getSpecs(b);
  const rows=[["الشركة",getBrand(a),getBrand(b)],["الشاشة",value(sa.display),value(sb.display)],["RAM",value(sa.ram),value(sb.ram)],["المعالج",value(sa.chipset),value(sb.chipset)],["البطارية",value(sa.battery),value(sb.battery)],["السنة",getYear(a),getYear(b)]];
  $("compareResult").innerHTML=`<table class="compare-table"><tr><th>${escapeHtml(getName(a))}</th><th>المواصفة</th><th>${escapeHtml(getName(b))}</th></tr>${rows.map(r=>`<tr><td>${escapeHtml(r[1])}</td><td>${escapeHtml(r[0])}</td><td>${escapeHtml(r[2])}</td></tr>`).join("")}</table>`;
}
function showModal(id){$(id).classList.remove("hidden")}
function fillSimulatorPhones() {
  $("simPhone").innerHTML = '<option value="">اختر هاتفاً من القائمة</option>' + phones.slice(0,1500).map((p,i)=>`<option value="${i}">${escapeHtml(getBrand(p)+" "+getName(p))}</option>`).join("");
}
function updateSimulation() {
  const p = phones[Number($("simPhone").value)];
  const battery = Number($("batteryLevel").value);
  const ramUse = Number($("ramLevel").value);
  const usage = Number($("usageLevel").value);
  const labels = ["","خفيف جداً","استخدام عادي","متوسط","ثقيل","ثقيل جداً"];
  $("usageLabel").textContent = labels[usage];
  $("simBattery").textContent = battery + "%";
  if (!p) { $("simScore").textContent="--"; $("simRam").textContent="--"; $("simEstimate").textContent="اختر هاتفاً من القائمة لعرض التقديرات."; return; }
  const sp = getSpecs(p);
  const ram = numericRam(sp.ram);
  const score = Math.max(12, Math.min(99, Math.round((ram*5 + (String(sp.chipset).length || 8)*1.2) * (1.2 - usage*.08))));
  const used = (ram * ramUse / 100).toFixed(1);
  const drain = (usage * (ram >= 12 ? 1.7 : 2.2));
  const hours = battery === 0 ? 0 : Math.round(battery / drain * 10) / 10;
  $("simScore").textContent = score + "/100";
  $("simRam").textContent = `${used} / ${ram} GB`;
  $("simEstimate").textContent = `على ${getBrand(p)} ${getName(p)}: استهلاك افتراضي تقريبي ${drain.toFixed(1)}% بالساعة في هذا النمط، أي نحو ${hours} ساعة من الشحنة الحالية. المؤشر ليس Benchmark حقيقياً.`;
}
function openOwnerPanel(info) {
  $("detailContent").innerHTML = `<div class="eyebrow">OWNER CONTROL CENTER</div><h2>لوحة المالك</h2><p>إدارة ومراقبة النسخة الحالية من الموقع.</p><div class="owner-stats"><article><b>${phones.length.toLocaleString("en-US")}</b><small>هاتف محمّل حالياً</small></article><article><b>${escapeHtml(info.security || "مفعّل")}</b><small>حماية الدخول</small></article></div><div class="owner-actions"><button class="outline-btn" id="ownerReload">تحديث بيانات الهواتف</button><button class="outline-btn" id="ownerHealth">فحص حالة الموقع</button><button class="outline-btn" id="ownerLogout">تسجيل الخروج</button></div><p id="ownerPanelMessage" class="message"></p><small>${escapeHtml(info.note || "")}</small>`;
  showModal("detailModal");
  $("ownerReload").addEventListener("click", async()=>{ $("ownerPanelMessage").textContent="جاري تحديث القائمة..."; await loadPhones(); $("ownerPanelMessage").textContent="انتهى تحديث القائمة."; });
  $("ownerHealth").addEventListener("click", async()=>{ try { const r=await fetch("/api/health"); const d=await r.json(); $("ownerPanelMessage").textContent=d.ok?"الموقع يعمل والخادم يستجيب.":"تعذر الفحص."; } catch { $("ownerPanelMessage").textContent="تعذر الوصول إلى الخادم."; } });
  $("ownerLogout").addEventListener("click",async()=>{await fetch("/api/owner/logout",{method:"POST"});$("detailModal").classList.add("hidden");});
}
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>$(b.dataset.close).classList.add("hidden")));
document.querySelectorAll(".modal").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)m.classList.add("hidden")}));
$("search").addEventListener("input",renderPhones);
$("brandFilter").addEventListener("change",renderPhones);
$("loadPhones").addEventListener("click",loadPhones);
$("compareNav").addEventListener("click",()=>showModal("compareModal"));
$("openCompare").addEventListener("click",()=>showModal("compareModal"));
$("compareA").addEventListener("change",compare); $("compareB").addEventListener("change",compare);
$("openSimulator").addEventListener("click",()=>showModal("simModal"));
document.querySelectorAll(".sim-apps button").forEach(b=>b.addEventListener("click",()=>{$("simResponse").textContent=`فتحت تطبيق ${b.dataset.app} التجريبي. هذه شاشة توضيحية فقط.`;}));
["simPhone","usageLevel","batteryLevel","ramLevel"].forEach(id=>$(id).addEventListener("input",updateSimulation));
$("ownerOpen").addEventListener("click",()=>{ $("ownerMessage").textContent=""; $("ownerCode").value=""; showModal("ownerModal"); });
$("ownerForm").addEventListener("submit",async e=>{
  e.preventDefault(); $("ownerMessage").textContent="جاري التحقق...";
  try{
    const r=await fetch("/api/owner/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code:$("ownerCode").value})});
    const data=await r.json();
    if(!r.ok) throw new Error(data.error||"فشل تسجيل الدخول");
    const panel=await fetch("/api/owner/panel");
    if(!panel.ok) throw new Error("تعذر فتح لوحة المالك");
    const info=await panel.json();
    $("ownerModal").classList.add("hidden");
    openOwnerPanel(info);
  }catch(err){$("ownerMessage").textContent=err.message;}
});
loadPhones();

